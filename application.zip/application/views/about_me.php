<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Me</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Pink Dark Mode with Black Morphism */
        body {
            background: #D6A2C5;
            color: #ffffff;
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0px;
            padding: 0;
        }

        .about-container {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-wrap: wrap;
            width: 100%;
            min-height: 100vh;
            padding: 30px;
            margin: auto;
            border-radius: 25px;
            box-shadow: 5px 5px 15px rgba(255, 105, 180, 0.3),
                        -5px -5px 15px rgba(255, 20, 147, 0.3);
        }

		.profile-img {
			background: none;
			position: fixed;
			top: 0;
			left: 0; /* Small left margin */
			width: auto; /* Keep aspect ratio */
			height: 100vh; /* Full viewport height */
			max-width: auto; /* Prevent excessive width */
			/* object-fit: contain; Ensures full image is visible */
			/* border-radius: 0 20px 20px 0; */
			z-index: 1000;
		}

/* Adjust content spacing */
.about-me {
    flex: 1;
    padding: 40px;
    background: rgba(30, 30, 30, 0.9);
    border-radius: 20px;
    box-shadow: 0px 5px 15px rgba(255, 20, 147, 0.8);
    max-width: 55%;
    margin-left: 32vw; /* Ensures text doesn’t overlap image */
	margin-bottom: 10px;
    border: 1px solid rgba(255, 105, 180, 0.3);
}

.about-me:hover {
    transform: translateY(-5px);
    box-shadow: 0px 8px 25px rgba(255, 20, 147, 0.8);
}

/* MOBILE SCREEN (SMALLER DEVICES) */
@media (max-width: 768px) {
    .profile-img {
        position: relative;
        width: 100%;
        height: auto;
        max-height: 50vh;
        border-radius: 0;
        left: 0; /* Reset margin for small screens */
    }

    .about-me {
        margin-left: 0;
        max-width: 100%;
        padding: 20px;
    }
}

.about-skills {
    flex: 1;
    padding: 40px;
    background: rgba(30, 30, 30, 0.9);
    border-radius: 20px;
    box-shadow: 0px 5px 15px rgba(255, 20, 147, 0.8);
    max-width: 55%;
    margin-left: 32vw; /* Ensures text doesn’t overlap image */
	margin-bottom: 10px;
    border: 1px solid rgba(255, 105, 180, 0.3);
}

.about-experience {
    flex: 1;
    padding: 40px;
    background: rgba(30, 30, 30, 0.9);
    border-radius: 20px;
    box-shadow: 0px 5px 15px rgba(255, 20, 147, 0.8);
    max-width: 55%;
    margin-left: 32vw; /* Ensures text doesn’t overlap image */
	margin-bottom: 10px;
    border: 1px solid rgba(255, 105, 180, 0.3);
}

.about-projects {
    flex: 1;
    padding: 40px;
    background: rgba(30, 30, 30, 0.9);
    border-radius: 20px;
    box-shadow: 0px 5px 15px rgba(255, 20, 147, 0.8);
    max-width: 55%;
    margin-left: 32vw; /* Ensures text doesn’t overlap image */
	margin-bottom: 10px;
    border: 1px solid rgba(255, 105, 180, 0.3);
}

.about-contact {
    flex: 1;
    padding: 40px;
    background: rgba(30, 30, 30, 0.9);
    border-radius: 20px;
    box-shadow: 0px 5px 15px rgba(255, 20, 147, 0.8);
    max-width: 55%;
    margin-left: 32vw; /* Ensures text doesn’t overlap image */
	margin-bottom: 10px;
    border: 1px solid rgba(255, 105, 180, 0.3);
}

.about-connect {
    flex: 1;
    padding: 40px;
    background: rgba(30, 30, 30, 0.9);
    border-radius: 20px;
    box-shadow: 0px 5px 15px rgba(255, 20, 147, 0.8);
    max-width: 55%;
    margin-left: 32vw; /* Ensures text doesn’t overlap image */
	margin-bottom: 10px;
    border: 1px solid rgba(255, 105, 180, 0.3);
}

.about-facts {
    flex: 1;
    padding: 40px;
    background: rgba(30, 30, 30, 0.9);
    border-radius: 20px;
    box-shadow: 0px 5px 15px rgba(255, 20, 147, 0.8);
    max-width: 55%;
    margin-left: 32vw; /* Ensures text doesn’t overlap image */
	margin-bottom: 10px;
    border: 1px solid rgba(255, 105, 180, 0.3);
}


        h1, h2 {
            color: #ff1493;
            text-shadow: 2px 2px 5px rgba(255, 20, 147, 0.6);
        }

        .section {
            background: rgba(50, 50, 50, 0.8);
            padding: 15px;
            border-radius: 15px;
            margin: 10px;
            box-shadow: inset 5px 5px 10px rgba(0, 0, 0, 0.3),
                        inset -5px -5px 10px rgba(255, 20, 147, 0.2);
            display: inline-flex;
            align-items: center;
        }

        .section i {
            margin-right: 10px;
            color: #ff69b4;
        }

        .social-links a {
            text-decoration: none;
            color: #ff69b4;
            font-size: 24px;
            margin: 10px;
            transition: transform 0.3s ease-in-out, color 0.3s;
        }

        .social-links a:hover {
            transform: scale(1.2);
            color: #ff1493;
        }

        @media (max-width: 768px) {
            .about-container {
                flex-direction: column;
                text-align: center;
                padding: 20px;
            }

            .about-text {
                max-width: 100%;
                margin-left: 0;
                padding: 30px;
            }

            .profile-img {
                width: 80vw;
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>

    <div class="about-container">
        <img src="<?php echo base_url('application/assets/images/bodypiccc1.png'); ?>" alt="Your Image" class="profile-img">

        <div class="about-me">
            <h1>About Me</h1>
            <p>I am Jenah Rivero, a Web Developer & Digital Creator. I graduated with a Bachelor’s degree in Information Systems, specializing in Web Development and Design from City College of Calapan. With expertise in PHP, Laravel, and CodeIgniter, I am passionate about building seamless, functional, and visually engaging digital solutions.</p>
        </div> 
		<div class="about-skills">
            <h2>Skills & Expertise</h2>
            <div class="section"><i class="fab fa-php"></i> PHP</div>
            <div class="section"><i class="fab fa-laravel"></i> Laravel</div>
            <div class="section"><i class="fas fa-code"></i> CodeIgniter</div>
            <div class="section"><i class="fab fa-java"></i> Java</div>
            <div class="section"><i class="fab fa-wordpress"></i> WordPress</div>
            <div class="section"><i class="fab fa-wix"></i> Wix</div>
            <div class="section"><i class="fas fa-paint-brush"></i> Digital Design</div>
            <div class="section"><i class="fas fa-tasks"></i> Project Management</div>
		</div>
		<div class="about-experience">
            <h2>Experience & Achievements</h2>
            <div class="section"><i class="fas fa-briefcase"></i> Freelance Web Developer – Built custom websites for small businesses.</div>
            <div class="section"><i class="fas fa-laptop-code"></i> Intern at [Company Name] – Developed a student registration system.</div>
            <div class="section"><i class="fas fa-award"></i> Capstone Project – Created a registration platform with GCash payment integration.</div>
		</div>
		<div class="about-projects">
            <h2>Notable Projects</h2>
            <div class="section"><i class="fas fa-folder-open"></i> <strong>Project Name</strong> <br> 📌 Developed a student registration system with GCash payment verification. <br> 🔗 <a href="https://yourprojectlink.com" target="_blank" style="color:#ff69b4;">Live Demo</a> <br> 🔧 Tech Stack: PHP, CodeIgniter, MySQL</div>
		</div>
		<div class="about-contact">
            <h2>Contact Information</h2>
            <div class="section"><i class="fas fa-envelope"></i> Email: your.email@example.com</div>
            <div class="section"><i class="fas fa-phone"></i> Phone: +63 900 123 4567</div>
            <div class="section"><i class="fas fa-map-marker-alt"></i> Location: [Your City], Philippines</div>
		</div>	
		<div class="about-connect">
            <h2>Connect with Me</h2>
            <div class="social-links">
                <a href="https://github.com/yourprofile" target="_blank"><i class="fab fa-github"></i></a>
                <a href="https://linkedin.com/in/yourprofile" target="_blank"><i class="fab fa-linkedin"></i></a>
                <a href="https://yourwebsite.com" target="_blank"><i class="fas fa-globe"></i></a>
            </div>
		</div>
		<div class="about-facts">
            <h2>Fun Facts</h2>
            <div class="section">🎨 I love UI/UX design and digital creativity.</div>
            <div class="section">🏀 I enjoy basketball and esports in my free time.</div>
            <div class="section">🌍 Passionate about technology and innovation.</div>
        </div>
		
   

</body>
</html>
