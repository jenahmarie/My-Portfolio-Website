<!-- header.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Portfolio</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
         * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
       
		
        .navbar {
            background: black;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 0 15px rgba(255, 105, 180, 0.8);
            position: relative;
            z-index: 10;
        }
        .navbar .logo {
            font-size: 20px;
            font-weight: bold;
            color: #ff69b4;
            text-shadow: 0 0 10px #ff69b4;
        }
        .navbar ul {
            list-style: none;
            display: flex;
        }
        .navbar ul li {
            margin: 0 15px;
        }
        .navbar ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
            position: relative;
        }
        .navbar ul li a:hover {
            color: #ff69b4;
            text-shadow: 0 0 10px #ff69b4;
        }

        /* Floating Circle Bubbles */
        .bubbles {
    position: fixed; /* Ensures it stays within the viewport */
    width: 100%;
    height: 100vh;
    top: 0;
    left: 0;
    overflow: hidden; /* Ensures no scrollbar appears */
    z-index: -1; /* Moves it behind other content */
}

.bubble {
    position: absolute;
    bottom: -10vh; /* Adjusted so it doesn’t extend too far */
    background: rgba(255, 255, 255, 0.2);
    border-radius: 50%;
    animation: floatUp linear infinite;
}

@keyframes floatUp {
    from {
        transform: translateY(0);
        opacity: 1;
    }
    to {
        transform: translateY(-110vh); /* Reduce height to avoid excessive overflow */
        opacity: 0;
    }
}

    </style>
</head>
<body>
    <div class="bubbles"></div>
    <div class="navbar">
        <div class="logo">My Portfolio</div>
        <ul>
		<li><a href="<?php echo base_url('index.php/home'); ?>">Home</a></li>
		<li><a href="<?php echo base_url('index.php/about_me'); ?>">About</a></li>
		<li><a href="<?php echo base_url('index.php/skills'); ?>">Skills</a></li>
		<li><a href="<?php echo base_url('index.php/portfolio'); ?>">Portfolio</a></li>
		<li><a href="<?php echo base_url('index.php/contact'); ?>">Contact</a></li>

        </ul>
    </div>

    <script>
        function createBubbles() {
            const bubbleContainer = document.querySelector(".bubbles");
            for (let i = 0; i < 20; i++) {
                let bubble = document.createElement("div");
                bubble.classList.add("bubble");
                let size = Math.random() * 60 + 10; // Size varies from 10px to 70px
                bubble.style.width = `${size}px`;
                bubble.style.height = `${size}px`;
                bubble.style.left = `${Math.random() * 100}%`;
                bubble.style.animationDuration = `${Math.random() * 5 + 3}s`; // Speed varies
                bubble.style.animationDelay = `${Math.random() * 2}s`; // Different start times
                bubbleContainer.appendChild(bubble);
                
                // Remove bubble when animation ends
                bubble.addEventListener("animationend", () => {
                    bubble.remove();
                });
            }
        }
        
        setInterval(createBubbles, 3000); // Generate bubbles every 3 seconds
    </script>
</body>
</html>