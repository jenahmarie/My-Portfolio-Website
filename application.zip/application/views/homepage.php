<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio - Home</title>

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>

body {
            background: #D6A2C5;
            color: white;
            text-align: center;
            position: relative;
			overflow: hidden;
        }
       
        .container {
			display: flex;
			align-items: center;
			gap: 20px; /* Small space between text and image */
			max-width: 1100px;
			margin-top: 100px;
			margin-left:100px ;
			padding: 20px;
			margin-right: 10vw; /* Push text away from the image */
		}

		.text-content {
			max-width: 70%;
			text-align: left;
		}


        h1 {
            font-size: 48px;
            color: white;
        }
        p {
            margin: 15px 0;
            color: white;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            margin: 10px 5px;
            background: white;
            color: #cc6699;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            box-shadow: 2px 2px 10px rgba(255, 255, 255, 0.3);
        }
        .btn:hover {
            background: #f5f5f5;
        }
        .social-links {
            margin-top: 20px;
        }

		.social-links a {
			display: inline-block;
			margin: 10px;
			font-size: 24px;
			color: white;
			text-decoration: none;
			transition: color 0.3s ease;
		}
		.social-links a:hover {
			color: #ff66b2;
		}

        img {
			position: fixed; 
			top: 0;
			margin-top: 40px;
			margin-right: 70px;
			right: 0; /* Move image to the right */
			width: 30vw; /* 30% of the screen width */
			height: 100vh; /* Full height */
			object-fit: cover; /* Show full image without cropping */
			z-index: 1000; 
		}
        .bubble {
            position: absolute;
            width: 120px;
            height: 120px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            filter: blur(10px);
            animation: float 6s infinite ease-in-out;
        }
        .bubble:nth-child(1) { top: 15%; left: 25%; animation-duration: 8s; }
        .bubble:nth-child(2) { top: 45%; left: 65%; animation-duration: 6s; }
        .bubble:nth-child(3) { top: 75%; left: 35%; animation-duration: 7s; }
        .bubble:nth-child(4) { top: 25%; left: 15%; animation-duration: 9s; }
        .bubble:nth-child(5) { top: 65%; left: 85%; animation-duration: 5s; }
        @keyframes float {
            0% { transform: translateY(0); opacity: 0.6; }
            50% { transform: translateY(-40px); opacity: 0.9; }
            100% { transform: translateY(0); opacity: 0.6; }
        }
    </style>
</head>
<body>
    
    <div class="bubble"></div>
    <div class="bubble"></div>
    <div class="bubble"></div>
    <div class="bubble"></div>
    <div class="bubble"></div>
    <div class="container">
        <div class="text-content">
            <p>Hi There!</p>
            <h1>I am Jenah Rivero <br>A Web Developer</h1>
            <p>Creating clean, modern, and professional web solutions.</p>
            <a href="#" class="btn">Hire Me</a>
            <a href="#" class="btn">View Portfolio</a>
            <div class="social-links">
				<a href="https://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
				<a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
				<a href="https://linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
			</div>

        </div>
        <img src="<?php echo base_url('application/assets/images/bodypiccc1.png'); ?>" alt="Your Image">
    </div>
</body>
</html>